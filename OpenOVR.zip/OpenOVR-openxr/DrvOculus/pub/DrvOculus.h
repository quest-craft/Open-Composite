#pragma once
#include "../OpenOVR/Drivers/Backend.h"

namespace DrvOculus {
	IBackend *CreateOculusBackend();
};
