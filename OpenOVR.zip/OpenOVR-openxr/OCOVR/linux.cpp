//
// Created by ZNix on 14/02/2021.
//

#include "stdafx.h"

#include "plat.h"

alternativeCoreFactory_t PlatformGetAlternativeCoreFactory()
{
	LINUX_STUBBED();
}
