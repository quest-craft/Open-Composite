#pragma once

#if defined(_DEBUG)
void GetStackWalk();
void DbgSetModule(HMODULE hModule);
#endif
