#pragma once
#include "../BaseCommon.h"

class BaseInputInternal {
public:
	// Hopefully they have <20 functions...
	void UknFunc001();
	void UknFunc002();
	void UknFunc003();
	void UknFunc004();
	void UknFunc005();
	void UknFunc006();
	void UknFunc007();
	void UknFunc008();
	void UknFunc009();
	void UknFunc010();
	void UknFunc011();
	void UknFunc012();
	void UknFunc013();
	void UknFunc014();
	void UknFunc015();
	void UknFunc016();
	void UknFunc017();
	void UknFunc018();
	void UknFunc019();
	void UknFunc020();
};
