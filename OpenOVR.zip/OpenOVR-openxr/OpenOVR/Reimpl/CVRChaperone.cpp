#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

GEN_INTERFACE("Chaperone", "003")
GEN_INTERFACE("Chaperone", "004")
