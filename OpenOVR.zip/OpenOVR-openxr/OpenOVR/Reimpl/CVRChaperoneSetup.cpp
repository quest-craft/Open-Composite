#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

GEN_INTERFACE("ChaperoneSetup", "005")
GEN_INTERFACE("ChaperoneSetup", "006")
