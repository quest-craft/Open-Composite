#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

GEN_INTERFACE("ControlPanel", "006", CUSTOM)
