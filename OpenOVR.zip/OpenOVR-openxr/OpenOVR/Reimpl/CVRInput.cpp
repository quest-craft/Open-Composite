#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

GEN_INTERFACE("Input", "004")
GEN_INTERFACE("Input", "005")
GEN_INTERFACE("Input", "006")
GEN_INTERFACE("Input", "007")
// version 8 and 9 are skipped
GEN_INTERFACE("Input", "010")
