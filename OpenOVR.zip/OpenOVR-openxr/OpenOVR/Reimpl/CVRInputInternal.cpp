#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

// This has never been published
GEN_INTERFACE("InputInternal", "002", CUSTOM)
