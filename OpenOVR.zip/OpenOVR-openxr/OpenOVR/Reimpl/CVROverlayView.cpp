#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

// Versions 1 and 2 aren't in any public releases
GEN_INTERFACE("OverlayView", "003")
