#include "stdafx.h"
#define GENFILE
#include "BaseCommon.h"

GEN_INTERFACE("RenderModels", "004")
GEN_INTERFACE("RenderModels", "005")
GEN_INTERFACE("RenderModels", "006")
