// Empty file to build libraries that are only interesting due to their dependencies, and that can't be
//  interface libraries for whatever reason.
// Scripts maybe isn't the best place to put this, but it'll do
// (note that if we put it in other places, it may be required to import stdafx after being glob-found)
