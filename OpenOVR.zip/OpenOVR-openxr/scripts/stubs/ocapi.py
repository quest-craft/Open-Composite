# This file is where the OpenComposite API generation should go.
# OC has an API that games could use, but (unsurprisingly) nothing ended up using it.
# The generated files were opencomposite.gen.h, opencomposite_api.gen.cs and opencomposite_capi.gen.h in OpenOVR/API
# Since they only ever had one method - to get the status of the menu button - it seems a waste of
# time to rewrite the code that generates them.
